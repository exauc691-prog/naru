enum AIMessageSender { user, assistant }
